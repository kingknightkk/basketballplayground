//
//  BasketballTimer1App.swift
//  BasketballTimer1
//
//  Created by 刘冠华 on 2022/4/5.
//

import SwiftUI

@main
struct BasketballTimer1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
